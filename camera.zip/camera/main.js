// Start Video Function

function startVideo(){
    document.getElementById("btn").style.display = "none";
    document.getElementById("video").style.display = "block";
    document.getElementById("closeBtn").style.display = "block";
    navigator.getUserMedia(
        { video : {} },
        stream => video.srcObject = stream,
        err => console.error(err),
    )
}

// Stop Video Function

function stopVideo(){
    window.open("index.html", "_self");
}
